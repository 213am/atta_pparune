import{j as i,W as s,n as t}from"./index-BEM99ApS.js";import{a as r}from"./index-BGRAlkBF.js";import{L as c}from"./loginStyle-CDRQEueO.js";const n=t.div`
  display: flex;
  justify-content: center;
`,x=t.img`
  width: 200px;
  margin-top: 30px;
`,e=t.div`
  font-size: 20px;
  span {
    color: #6f4cdb;
  }
`,l=t.h1`
  margin-top: 30px;
  margin-bottom: 30px;
  font-size: 24px;
`,a=t.div`
  margin: 20px 0;
  padding: 15px 20px;
  border-radius: 5px;
  background-color: #eee;
  width: 500px;
  text-align: center;
`,d=t.div`
  font-size: 18px;
  margin-bottom: 10px;
  font-weight: 700;
`,o=t.div`
  margin-top: 5px;
  color: #999;
`;function j(){return i.jsxs(c,{children:[i.jsx(n,{children:i.jsx(x,{src:"/emailauth.png",alt:"이메일 인증"})}),i.jsx(l,{children:"인증 메일이 발송되었습니다."}),i.jsxs(e,{children:["메일함에서 (",i.jsx("span",{children:"jumoney1012@gmail.com"}),") 인증 메일을 확인 바랍니다."]}),i.jsx(e,{children:"이메일에서 인증 확인 링크를 선택하면 이메일 인증이 완료됩니다."}),i.jsx(n,{children:i.jsxs(a,{children:[i.jsx(d,{children:"유의사항"}),i.jsx(o,{children:"1. 인증메일은 발송 시점으로부터 24시간 동안만 유효합니다."}),i.jsx(o,{children:"2. 메일이 도착하지 않았다면 스팸함을 확인해 주시기 바랍니다."})]})}),i.jsxs(s,{to:"/auth",children:[i.jsx(r,{style:{width:24,height:24}}),"로그인 하러가기"]})]})}export{j as default};
